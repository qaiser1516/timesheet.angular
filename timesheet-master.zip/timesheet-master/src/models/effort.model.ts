export class EffortModel {

    taskId: number;

    employeeId: number;

    mondayHours: number;

    tuesdayHours: number;

    wednesdayHours: number;

    thursdayHours: number;

    fridayHours: number;

    saturdayHours: number;

    sundayHours: number;
}