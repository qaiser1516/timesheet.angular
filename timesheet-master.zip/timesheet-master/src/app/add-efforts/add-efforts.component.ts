import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { TaskService } from '../services/tasks.service';
import { EffortModel } from 'src/models/effort.model';
import { EffortService } from '../services/effort.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-add-efforts',
    templateUrl: './add-efforts.component.html',
    styleUrls: ['./add-efforts.component.scss']
})
export class AddEffortsComponent implements OnInit {

    employees: any;
    tasks: any;
    effortModel: EffortModel = new EffortModel();

    constructor(private employeeService: EmployeeService,
        private taskService: TaskService, private effortService: EffortService,
        private route: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.route.paramMap.subscribe(params => {
            this.effortModel.employeeId = parseInt(params.get("id"));
        })
        this.GetEmployees();
        this.GetTasks();
    }

    GetEmployees() {
        this.employeeService.getallemployees().subscribe(data => {
            this.employees = data;
        });
    }

    GetTasks() {
        this.taskService.getallTasks().subscribe(data => {
            this.tasks = data;
        });
    }

    submit() {
        this.effortModel;
        this.effortService.addEffort(this.effortModel).subscribe(result => {
            if (result)
                this.router.navigate(['/list']);
            else
                alert("Error while adding efforts");
        });

    }
}
