import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class EffortService {
    private baseapi = environment.apiUrl;
    constructor(private http: HttpClient) { }


    getallEfforts() {
        return this.http.get(this.baseapi + "/efforts/getall");
    }

    addEffort(effort: any) {
        return this.http.post(this.baseapi + "/efforts/addeffort", effort);
    }

    geteffortbyemployee(employeeId: number) {
        return this.http.get<any>(`${this.baseapi}/efforts/geteffortbyemployee/${employeeId}`);
    }
}