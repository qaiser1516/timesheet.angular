import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { ActivatedRoute } from '@angular/router';
import { EffortService } from '../services/effort.service';
import { TaskService } from '../services/tasks.service';

@Component({
    selector: 'app-timesheet',
    templateUrl: './timesheet.component.html',
    styleUrls: ['./timesheet.component.scss']
})
export class TimesheetComponent implements OnInit {

    employees: any;
    employeeId: number;
    efforts: any;
    tasks: any;
    totalHours: any = {};

    constructor(private employeeService: EmployeeService,
        private effortService: EffortService, private taskService: TaskService, private route: ActivatedRoute) {
            this.InitializeTotalHours();
    }

    InitializeTotalHours(){
        this.totalHours.mondayTotal = 0;
        this.totalHours.tuesdayTotal = 0;
        this.totalHours.wednesdayTotal = 0;
        this.totalHours.thursdayTotal = 0;
        this.totalHours.fridayTotal = 0;
        this.totalHours.saturdayTotal = 0;
        this.totalHours.sundayTotal = 0;
    }

    ngOnInit() {
        this.route.paramMap.subscribe(params => {
            this.employeeId = parseInt(params.get("id"));
        })
        this.GetAllEmployeeDetails();
        this.GetAllEffortsDetails();
        this.GetTasks();
    }

    GetAllEmployeeDetails() {
        this.employeeService.getallemployees().subscribe(data => {
            this.employees = data;
        });
    }

    GetTasks() {
        this.taskService.getallTasks().subscribe(data => {
            this.tasks = data;
        });
    }

    GetAllEffortsDetails() {
        this.effortService.geteffortbyemployee(this.employeeId).subscribe(result => {
            this.efforts = result;
            this.CalculateTotalEfforts();
        });
    }

    CalculateTotalEfforts() {
        this.efforts.forEach(element => {
            this.totalHours.mondayTotal += element.mondayHours;
            this.totalHours.tuesdayTotal += element.tuesdayHours;
            this.totalHours.wednesdayTotal += element.wednesdayHours;
            this.totalHours.thursdayTotal += element.thursdayHours;
            this.totalHours.fridayTotal += element.fridayHours;
            this.totalHours.saturdayTotal += element.saturdayHours;
            this.totalHours.sundayTotal += element.sundayHours;
        });
    }

    UpdateTimeSheet(){
        this.InitializeTotalHours();
        this.GetAllEffortsDetails();
        this.GetTasks();
    }

}
