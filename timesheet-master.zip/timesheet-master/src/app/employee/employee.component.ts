import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { EffortService } from '../services/effort.service';

@Component({
    selector: 'employee-list',
    templateUrl: 'employee.component.html',
    styleUrls: ['./employee.component.scss']
})

export class EmployeeListComponent implements OnInit {
    employees: any;
    efforts: any;
    constructor(private employeeService: EmployeeService, private effortService: EffortService) { }

    ngOnInit() {
        this.employeeService.getallemployees().subscribe(data => {
            this.employees = data;
        });
        this.GetAllEffortsDetails();
    }

    GetAllEffortsDetails() {
        this.effortService.getallEfforts().subscribe(result => {
            this.efforts = result;
            this.setupModel();
        });
    }

    setupModel() {
        this.employees.forEach(employee => {
            employee.totalEffort = 0;
            employee.averageEffort = 0;
            var filterResult = this.efforts.filter(o => o.employeeId == employee.id);
            filterResult.forEach(element => {
                employee.totalEffort += element.mondayHours;
                employee.totalEffort += element.tuesdayHours;
                employee.totalEffort += element.wednesdayHours;
                employee.totalEffort += element.thursdayHours;
                employee.totalEffort += element.fridayHours;
                employee.totalEffort += element.saturdayHours;
                employee.totalEffort += element.sundayHours;
            });
            employee.averageEffort = employee.totalEffort / 7;
        });
    }
}