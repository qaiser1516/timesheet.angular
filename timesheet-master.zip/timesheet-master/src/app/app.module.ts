import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee/employee.component';
import { EmployeeService } from './services/employee.service';
import { TimesheetComponent } from './timesheet/timesheet.component';
import { RouterModule, Routes } from '@angular/router';
import { AddEffortsComponent } from './add-efforts/add-efforts.component';
import { TaskService } from './services/tasks.service';
import { from } from 'rxjs';
import { EffortService } from './services/effort.service';

const roots: Routes = [
  { path: '', redirectTo: '/list', pathMatch: 'full' },
  { path: 'list', component: EmployeeListComponent },
  { path: 'timesheet/:id', component: TimesheetComponent },
  { path: 'add/:id', component: AddEffortsComponent }
]

@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    TimesheetComponent,
    AddEffortsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(roots)
  ],
  providers: [
    EmployeeService,
    TaskService,
    EffortService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
